const appSettings = {
    data: "http://memory-cards-api.safipeti.com/",
    categoryId: 2,
    topicId: 1,
    imgSrc: "http://memory-cards-api.safipeti.com/img/",
    cols: 4,
    cardSize: 8,
};
